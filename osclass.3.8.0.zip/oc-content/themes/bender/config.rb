css_dir = "css"
sass_dir = "sass"
output_style = :compressed #:expanded or :nested or :compact or :compressed
line_comments = false